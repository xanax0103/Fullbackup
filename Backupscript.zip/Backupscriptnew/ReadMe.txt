main.py
Script som laver backup af folder.
Spørger efter source og destination, samt tjekker indhold af mappen.
Derefter skal du godkende, før den går i gang.
